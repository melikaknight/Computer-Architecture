/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;


public class LexicalAnalyzer {
    File input;
    FileInputStream fis;
    Queue<Token> tokens;
    int lineNumber=1;
    public LexicalAnalyzer(String filename) throws FileNotFoundException, IOException {
        input=new File(filename);
        fis=new FileInputStream(input);
        tokens=new LinkedList();
        Read();
    }
    void Read() throws IOException {
        int read;
        String temp="";
        while((read=fis.read())!=-1) {
            if(temp.equals("//")) { // Single line comment
                while(read!=13 && read!=10) { read=fis.read(); }
                temp="";
            }
            if(temp.equals("/*")) { // Multiple line comment
                do {
                    if(read=='*') {
                        read=fis.read();
                        if(read=='/') {
                            break;
                        } else {
                            continue;
                        }
                    }
                    read=fis.read();
                } while (true);
                read=fis.read();
                temp="";
            }
            if(read!=32 && read!=9 && read!=13 && read!=10) {
                temp=temp+(char)read;
            } else {
                if(read==10) {
                    lineNumber++;
                }
                if(!temp.equals("")) {
                    tokens.add(new Token(temp,lineNumber));
                    temp="";
                }
            }
        }
        if(!temp.equals("")) {
            tokens.add(new Token(temp,lineNumber));
            temp="";
        }
    }
    
}