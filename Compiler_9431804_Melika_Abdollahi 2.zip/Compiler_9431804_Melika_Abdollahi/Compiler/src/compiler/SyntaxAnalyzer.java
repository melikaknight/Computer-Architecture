/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compiler;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

public class SyntaxAnalyzer {
    String[][] grammer;
    int[][] parseTable;
    Stack<String> parseStack;
    List<String> heads;
    List<String> rows;
    static Token t;
    
    public SyntaxAnalyzer() {
        rows=new LinkedList<>();
        heads=Arrays.asList("int",";","bool","char",",","id","=","if","(",")","{","}","else","while","++","--","+=","-=","*=","/=","%=","null","+","-","*","/","num","&&","||","!","==","!=","<=",">=","<",">","true","false","$");
        grammer=new String[][]{
            {"PROGRAM","DECL","STMT"},
            {"DECL","DECL2","DECL"},
            {"DECL","lambda"},
            {"DECL2","int","DECLINT",";"},
            {"DECL2","bool","DECLBOOL",";"},
            {"DECL2","char","DECLCHAR",";"},
            {"DECLINT","DECLINT2","DECLINT3"},
            {"DECLINT3",",","DECLINT2","DECLINT3"},
            {"DECLINT3","lambda"},
            {"DECLINT2","@createInt","id","DECLINT5"},
            {"DECLINT5","=","E","@assign"},
            {"DECLINT5","lambda","@pop"},
            {"DECLBOOL","DECLBOOL2","DECLBOOL3"},
            {"DECLBOOL3",",","DECLBOOL2","DECLBOOL3"},
            {"DECLBOOL3","lambda"},
            {"DECLBOOL2","@createBool","id","DECLBOOL5"},
            {"DECLBOOL5","=","@bval","BVAL","@assign"},
            {"DECLBOOL5","lambda","@pop"},
            {"DECLCHAR","DECLCHAR2","DECLCHAR3"},
            {"DECLCHAR3",",","DECLCHAR2","DECLCHAR3"},
            {"DECLCHAR3","lambda"},
            {"DECLCHAR2","@createChar","id","DECLCHAR5"},
            {"DECLCHAR5","=","E","@assign"},
            {"DECLCHAR5","lambda","@pop"},
            {"STMT","IFBLOCK","STMT"},
            {"STMT","WHLBLOCK","STMT"},
            {"STMT","ASGNMNT","STMT"},
            {"STMT","lambda"},
            {"IFBLOCK","if","(","BEXPR",")","@jz","{","STMT","}","EP"},
            {"EP","else","EP2"},
            {"EP","lambda","@compjz"},
            {"EP2","@jpcompjz","{","STMT","}","@compjp"},
            {"EP2","@jpcompjz","IFBLOCK","@compjp"},
            {"WHLBLOCK","while","@save","(","BEXPR",")","@jz","{","STMT","}","@endloop"},
            {"ASGNMNT","@pid","id","ASGNMNT2"},
            {"ASGNMNT2","++","@plusplus",";"},
            {"ASGNMNT2","--","@minusminus",";"},
            {"ASGNMNT2","=","E","@assign",";"},
            {"ASGNMNT2","+=","E","@addassign",";"},
            {"ASGNMNT2","-=","E","@subassign",";"},
            {"ASGNMNT2","*=","E","@mulassign",";"},
            {"ASGNMNT2","/=","E","@divassign",";"},
            {"ASGNMNT2","%=","E","@remassign",";"},
            {"E","null"},
            {"E","T","E2"},
            {"E2","+","T","@add","E2"},
            {"E2","-","T","@sub","E2"},
            {"E2","lambda"},
            {"T","F","T2"},
            {"T2","*","F","@mult","T2"},
            {"T2","/","F","@div","T2"},
            {"T2","lambda"},
            {"F","@pid","id"},
            {"F","@num","num"},
            {"F","(","E",")"},
            {"BEXPR","BEXPR3","BEXPR2"},
            {"BEXPR2","&&","BEXPR3","BEXPR2","@and"},
            {"BEXPR2","||","BEXPR3","BEXPR2","@or"},
            {"BEXPR2","lambda"},
            {"BEXPR3","!","BEXPR3","@not"},
            {"BEXPR3","BVAL"},
            {"BEXPR3","E","BEXPR4"},
            {"BEXPR4","==","E","@cpequal"},
            {"BEXPR4","!=","E","@cpnotequal"},
            {"BEXPR4","<=","E","@cpequallower"},
            {"BEXPR4",">=","E","@cpequalhigher"},
            {"BEXPR4","<","E","@cplower"},
            {"BEXPR4",">","E","@cphigher"},
            {"BVAL","true"},
            {"BVAL","false"}
        };
        for (String[] grammer1 : grammer) {
            if (!rows.contains(grammer1[0])) {
                rows.add(grammer1[0]);
            }
        }
        parseTable=new int[][]{{1,0,1,1,0,1,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{2,0,2,2,0,3,0,3,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3},{4,0,5,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,9,0,0,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,12,0,0,12,0,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,13,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,15,0,0,14,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,18,0,0,18,0,17,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,19,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,21,0,0,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,24,0,0,24,0,23,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,27,0,25,0,0,0,28,0,26,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,28},{0,0,0,0,0,0,0,29,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,31,0,31,0,0,0,31,30,31,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,31},{0,0,0,0,0,0,0,33,0,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,34,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,35,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,38,0,0,0,0,0,0,0,36,37,39,40,41,42,43,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,45,0,0,45,0,0,0,0,0,0,0,0,0,0,0,0,44,0,0,0,0,45,0,0,0,0,0,0,0,0,0,0,0,0},{0,48,0,0,48,0,0,0,0,48,0,0,0,0,0,0,0,0,0,0,0,0,46,47,0,0,0,48,48,0,48,48,48,48,48,48,0,0,0},{0,0,0,0,0,49,0,0,49,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,49,0,0,0,0,0,0,0,0,0,0,0,0},{0,52,0,0,52,0,0,0,0,52,0,0,0,0,0,0,0,0,0,0,0,0,52,52,50,51,0,52,52,0,52,52,52,52,52,52,0,0,0},{0,0,0,0,0,53,0,0,55,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,54,0,0,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,56,0,0,56,0,0,0,0,0,0,0,0,0,0,0,0,56,0,0,0,0,56,0,0,56,0,0,0,0,0,0,56,56,0},{0,0,0,0,0,0,0,0,0,59,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,57,58,0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,62,0,0,62,0,0,0,0,0,0,0,0,0,0,0,0,62,0,0,0,0,62,0,0,60,0,0,0,0,0,0,61,61,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,63,64,65,66,67,68,0,0,0},{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69,70,0}};
        parseStack=new Stack<>();
        parseStack.push("$");
        parseStack.push(grammer[0][0]);
    }
    int getPrad(String s1,String s2) {
        int i=rows.indexOf(s1);
        int j=heads.indexOf(s2);
        if(i==-1) {
            return 0;
        }
        if(j==-1) {
            return 0;
        }
        return parseTable[i][j];
    }
    void startParsing() throws NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        t=Compiler.getRealToken();
        while(!parseStack.isEmpty()) {     
            if(Character.isUpperCase(parseStack.peek().charAt(0))) {
                int prad=getPrad(parseStack.peek(),Compiler.getToken(t).token);
                if(prad==0) {
                    System.err.println("*** Syntax Analyzer ***");
                    if(t.token.equals("$")) {
                        System.err.println("Error: syntax error found on line "+t.line);
                    } else {
                        System.err.println("Error: syntax error found on line "+t.line+" near \""+t.token+"\"");
                    }
                    
                    System.exit(0);
                }
                parseStack.pop();
                for(int i=(grammer[prad-1].length-1); i>=1; i--) {
                    if(!"lambda".equals(grammer[prad-1][i])) {
                        parseStack.push(grammer[prad-1][i]);
                    }
                }
            } else if(parseStack.peek().charAt(0)=='@') {
                Method method = CodeGenerator.class.getDeclaredMethod(parseStack.peek().substring(1,parseStack.peek().length()));
                parseStack.pop();
                method.invoke(Compiler.generator);
            } else if(parseStack.peek().equals(Compiler.getToken(t).token)) {
                parseStack.pop();
                t=Compiler.getRealToken();
            } else {
                System.err.println("*** Syntax Analyzer ***");
                if(t.token.equals("$")) {
                    System.err.println("Error: syntax error found on line "+t.line);
                } else {
                    System.err.println("Error: syntax error found on line "+t.line+" near \""+t.token+"\"");
                }
                System.exit(0);
            }
        }
        System.out.println("-- Parsing finished --");
    }
}
