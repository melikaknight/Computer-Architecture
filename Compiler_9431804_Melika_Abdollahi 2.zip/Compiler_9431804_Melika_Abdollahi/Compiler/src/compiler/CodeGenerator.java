
package compiler;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Stack;


public class CodeGenerator {
    Map<String,Integer> symbolTable;
    Stack<String> semanticStack;
    List<String[]> assemblyCodes;
    private final File output,output2;
    int PC;
    int memoryDataPtr;
    public CodeGenerator(String s1,String s2) {
        semanticStack=new Stack<>();
        assemblyCodes=new LinkedList<>();
        symbolTable=new HashMap<>();
        output=new File(s1);
        output2=new File(s2);
        PC=0;
        memoryDataPtr=0;
    }
    void createInt() {
        if(symbolTable.containsKey(SyntaxAnalyzer.t.token)) {
            System.err.println("*** Semantic Analyzer ***");
            System.err.println("Error: Semantic error found on line "+SyntaxAnalyzer.t.line);
            System.err.println("Error: This id is already defined: "+SyntaxAnalyzer.t.token);
            System.exit(0);
        }
        semanticStack.add(memoryDataPtr+"");
        symbolTable.put(SyntaxAnalyzer.t.token,memoryDataPtr);
        memoryDataPtr++;
    }
    void createBool() {
        if(symbolTable.containsKey(SyntaxAnalyzer.t.token)) {
            System.err.println("*** Semantic Analyzer ***");
            System.err.println("Error: Semantic error found on line "+SyntaxAnalyzer.t.line);
            System.err.println("Error: This id is already defined: "+SyntaxAnalyzer.t.token);
            System.exit(0);
        }
        semanticStack.add(memoryDataPtr+"");
        symbolTable.put(SyntaxAnalyzer.t.token,memoryDataPtr);
        memoryDataPtr++;
    }
    void createChar() {
        if(symbolTable.containsKey(SyntaxAnalyzer.t.token)) {
            System.err.println("*** Semantic Analyzer ***");
            System.err.println("Error: Semantic error found on line "+SyntaxAnalyzer.t.line);
            System.err.println("Error: This id is already defined: "+SyntaxAnalyzer.t.token);
            System.exit(0);
        }
        semanticStack.add(memoryDataPtr+"");
        symbolTable.put(SyntaxAnalyzer.t.token,memoryDataPtr);
        memoryDataPtr++;
    }
    void pid() {
        if(!symbolTable.containsKey(SyntaxAnalyzer.t.token)) {
            System.err.println("*** Semantic Analyzer ***");
            System.err.println("Error: Semantic error found on line "+SyntaxAnalyzer.t.line);
            System.err.println("Error: This id is not defined: "+SyntaxAnalyzer.t.token);
            System.exit(0);
        }
        semanticStack.add(symbolTable.get(SyntaxAnalyzer.t.token)+"");
    }
    void num() {
        assemblyCodes.add(new String[]{"mil","t0","low(#"+SyntaxAnalyzer.t.token+")"});
        assemblyCodes.add(new String[]{"mih","t0","high(#"+SyntaxAnalyzer.t.token+")"});
        assemblyCodes.add(new String[]{"mil","t1","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t1","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t1","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=5;
        memoryDataPtr++;
    }
    void assign() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t1","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t1","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t0","t1","nop"});
        assemblyCodes.add(new String[]{"mil","t1","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t1","high("+opr2+")"});
        assemblyCodes.add(new String[]{"sta","t1","t0","nop"});
        PC+=6;
    }
    void addassign() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","add","t0","t1"});       
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        PC+=7;
    }
    void subassign() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","sub","t0","t1"});       
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        PC+=7;
    }
    void mulassign() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","mul","t0","t1"});       
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        PC+=7;
    }
    void divassign() {

    }
    void remassign() {
        
    }
    void plusplus() {
        String opr=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t1","low(#1)"});
        assemblyCodes.add(new String[]{"mih","t1","high(#1)"});
        assemblyCodes.add(new String[]{"add","t0","t1","sta","t2","t0"});
        PC+=6;
    }
    void minusminus() {
        String opr=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t1","low(#1)"});
        assemblyCodes.add(new String[]{"mih","t1","high(#1)"});
        assemblyCodes.add(new String[]{"sub","t0","t1","sta","t2","t0"});
        PC+=6;
    }
    void add() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","add","t0","t1"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=9;
        memoryDataPtr++;
    }
    void sub() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","sub","t0","t1"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=9;
        memoryDataPtr++;
    }
    void mult() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","mul","t0","t1"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=9;
        memoryDataPtr++;
    }
    void div() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low(#0)"});
        assemblyCodes.add(new String[]{"mih","t2","high(#0)"});
        assemblyCodes.add(new String[]{"mil","t3","low(#1)"});
        assemblyCodes.add(new String[]{"mih","t3","high(#1)"});
        assemblyCodes.add(new String[]{"cmp","t0","t1","nop"});
        assemblyCodes.add(new String[]{"brc","5"});
        assemblyCodes.add(new String[]{"sub","t0","t1","add","t2","t3"});
        assemblyCodes.add(new String[]{"mil","t3","low(#"+(PC+8)+")"});
        assemblyCodes.add(new String[]{"mih","t3","high(#"+(PC+8)+")"});
        assemblyCodes.add(new String[]{"jpa","t3","0"});
        assemblyCodes.add(new String[]{"mil","t0","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t0","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t0","t2","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=19;
        memoryDataPtr++;
    }
    void pop() {
        semanticStack.pop();
    }
    void jz() {
        String opr=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t1","low(#0)"});
        assemblyCodes.add(new String[]{"mih","t1","high(#0)"});
        assemblyCodes.add(new String[]{"cmp","t0","t1","nop"});
        assemblyCodes.add(new String[]{"brz",""});
        semanticStack.add((PC+6)+"");
        PC+=7;
    }
    void jpcompjz() {
        int index = Integer.parseInt(semanticStack.pop());
        assemblyCodes.get(index)[1]=(PC-index+2+"");
        assemblyCodes.add(new String[]{"mil","t0",""});
        assemblyCodes.add(new String[]{"mih","t0",""});
        assemblyCodes.add(new String[]{"jpa","t0","0"});
        semanticStack.add(PC+"");
        PC+=3;
    }
    void compjp() {
        assemblyCodes.get(Integer.parseInt(semanticStack.peek()))[2]=("low(#"+PC+")");
        assemblyCodes.get(Integer.parseInt(semanticStack.pop())+1)[2]=("high(#"+PC+")");
    }
    void compjz() {
        int index = Integer.parseInt(semanticStack.pop());
        assemblyCodes.get(index)[1]=(PC-index-1+"");
    }
    void save() {
        semanticStack.add(PC+"");
    }
    void endloop() {
        int index = Integer.parseInt(semanticStack.pop());
        assemblyCodes.get(index)[1]=((PC-index+2)+"");
        assemblyCodes.add(new String[]{"mil","t0","low(#"+semanticStack.peek()+")"});
        assemblyCodes.add(new String[]{"mih","t0","high(#"+semanticStack.pop()+")"});
        assemblyCodes.add(new String[]{"jpa","t0","0"});
        PC+=3;
    }
    void cpequal() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","cmp","t0","t1"});
        assemblyCodes.add(new String[]{"brz","3"});
        assemblyCodes.add(new String[]{"mil","t0","0"});
        assemblyCodes.add(new String[]{"mih","t0","0"});
        assemblyCodes.add(new String[]{"jpr","2"});
        assemblyCodes.add(new String[]{"mil","t0","255"});
        assemblyCodes.add(new String[]{"mih","t0","255"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=15;
        memoryDataPtr++;       
    }
    void cpnotequal() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","cmp","t0","t1"});
        assemblyCodes.add(new String[]{"brz","3"});
        assemblyCodes.add(new String[]{"mil","t0","255"});
        assemblyCodes.add(new String[]{"mih","t0","255"});
        assemblyCodes.add(new String[]{"jpr","2"});
        assemblyCodes.add(new String[]{"mil","t0","0"});
        assemblyCodes.add(new String[]{"mih","t0","0"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=15;
        memoryDataPtr++;    
    }
    void cpequallower() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","cmp","t1","t0"});
        assemblyCodes.add(new String[]{"brc","3"});
        assemblyCodes.add(new String[]{"mil","t0","255"});
        assemblyCodes.add(new String[]{"mih","t0","255"});
        assemblyCodes.add(new String[]{"jpr","2"});
        assemblyCodes.add(new String[]{"mil","t0","0"});
        assemblyCodes.add(new String[]{"mih","t0","0"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=15;
        memoryDataPtr++;   
    }
    void cpequalhigher() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","cmp","t0","t1"});
        assemblyCodes.add(new String[]{"brc","3"});
        assemblyCodes.add(new String[]{"mil","t0","255"});
        assemblyCodes.add(new String[]{"mih","t0","255"});
        assemblyCodes.add(new String[]{"jpr","2"});
        assemblyCodes.add(new String[]{"mil","t0","0"});
        assemblyCodes.add(new String[]{"mih","t0","0"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=15;
        memoryDataPtr++;  
    }
    void cphigher() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","cmp","t1","t0"});
        assemblyCodes.add(new String[]{"brc","3"});
        assemblyCodes.add(new String[]{"mil","t0","0"});
        assemblyCodes.add(new String[]{"mih","t0","0"});
        assemblyCodes.add(new String[]{"jpr","2"});
        assemblyCodes.add(new String[]{"mil","t0","255"});
        assemblyCodes.add(new String[]{"mih","t0","255"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=15;
        memoryDataPtr++; 
    }
    void cplower() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","cmp","t0","t1"});
        assemblyCodes.add(new String[]{"brc","3"});
        assemblyCodes.add(new String[]{"mil","t0","0"});
        assemblyCodes.add(new String[]{"mih","t0","0"});
        assemblyCodes.add(new String[]{"jpr","2"});
        assemblyCodes.add(new String[]{"mil","t0","255"});
        assemblyCodes.add(new String[]{"mih","t0","255"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=15;
        memoryDataPtr++;
    }
    void bval() {
        if("true".equals(SyntaxAnalyzer.t.token)) {
            assemblyCodes.add(new String[]{"mil","t0","255"});
            assemblyCodes.add(new String[]{"mih","t0","255"});
        } else {
            assemblyCodes.add(new String[]{"mil","t0","0"});
            assemblyCodes.add(new String[]{"mih","t0","0"});
        }
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=5;
        memoryDataPtr++;
    }
    void not() {
        String opr1=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","not","t0"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=6;
        memoryDataPtr++; 
    }
    void and() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","and","t0","t1"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=9;
        memoryDataPtr++;
    }
    void or() {
        String opr1=semanticStack.pop();
        String opr2=semanticStack.pop();
        assemblyCodes.add(new String[]{"mil","t2","low("+opr2+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr2+")"});
        assemblyCodes.add(new String[]{"lda","t0","t2","nop"});
        assemblyCodes.add(new String[]{"mil","t2","low("+opr1+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+opr1+")"});
        assemblyCodes.add(new String[]{"lda","t1","t2","orr","t0","t1"});
        assemblyCodes.add(new String[]{"mil","t2","low("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"mih","t2","high("+memoryDataPtr+")"});
        assemblyCodes.add(new String[]{"sta","t2","t0","nop"});
        semanticStack.add(memoryDataPtr+"");
        PC+=9;
        memoryDataPtr++; 
    }
    void generateCode() throws IOException {
        FileWriter fw = new FileWriter(output.getAbsoluteFile());
        FileWriter fw2 = new FileWriter(output2.getAbsoluteFile());
        try (BufferedWriter bw = new BufferedWriter(fw)) {
            try (BufferedWriter bw2 = new BufferedWriter(fw2)) {
                for(String assembly[]:assemblyCodes) {
                    for(int i=0; i<assembly.length; i++) {
                        if(assembly[i].startsWith("low(") && !assembly[i].startsWith("low(#")) {
                            String t = assembly[i];
                            int n1,n2;
                            n1 = t.indexOf('(');
                            n2 = t.indexOf(')');
                            assembly[i] = "low("+String.valueOf(Integer.parseInt(t.substring(n1+1,n2))+assemblyCodes.size()+1)+")";
                        } else if (assembly[i].startsWith("high(") && !assembly[i].startsWith("high(#")) {
                            String t = assembly[i];
                            int n1,n2;
                            n1 = t.indexOf('(');
                            n2 = t.indexOf(')');
                            assembly[i] = "high("+String.valueOf(Integer.parseInt(t.substring(n1+1,n2))+assemblyCodes.size()+1)+")";
                        }
                    }
                }
                for(String assembly[]:assemblyCodes) {
                    int i;
                    if(assembly.length>3) {
                        int k=0;
                        for(i=1; i<assembly.length; i++) {
                            if(assembly[i].length()==3) {
                                k=i;
                            }
                        }
                        bw.write(assembly[0]+" ");
                        for(i=1; i<k-1; i++) {
                            bw.write(assembly[i]+",");
                            assembly[i] = String.format("%2s", Integer.toBinaryString(Integer.parseInt(assembly[i].substring(1)))).replace(' ', '0');
                        }
                        bw.write(assembly[k-1]+"\t\t\t"+assembly[k]+" ");
                        assembly[k-1] = String.format("%2s", Integer.toBinaryString(Integer.parseInt(assembly[k-1].substring(1)))).replace(' ', '0');
                        for(i=k+1; i<(assembly.length-1); i++) {
                            bw.write(assembly[i]+",");
                            assembly[i] = String.format("%2s", Integer.toBinaryString(Integer.parseInt(assembly[i].substring(1)))).replace(' ', '0');
                        }
                        if(i<assembly.length) {
                            bw.write(assembly[i]);
                            assembly[i] = String.format("%2s", Integer.toBinaryString(Integer.parseInt(assembly[i].substring(1)))).replace(' ', '0');
                        }
                        bw.write("\r\n");
                        if(assembly[0].equals("nop")) {
                            bw2.write("00000000");
                        } else if(assembly[0].equals("mvr")) {
                            bw2.write("0001");
                            bw2.write(assembly[1]);
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("lda")) {
                            bw2.write("0010");
                            bw2.write(assembly[1]);
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("sta")) {
                            bw2.write("0011");
                            bw2.write(assembly[1]);
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("and")) {
                            bw2.write("0110");
                            bw2.write(assembly[1]);
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("orr")) {
                            bw2.write("0111");
                            bw2.write(assembly[1]);
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("not")) {
                            bw2.write("1000");
                            bw2.write(assembly[1]);
                        } else if(assembly[0].equals("add")) {
                            bw2.write("1011");
                            bw2.write(assembly[1]);
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("sub")) {
                            bw2.write("1100");
                            bw2.write(assembly[1]);
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("mul")) {
                            bw2.write("1101");
                            bw2.write(assembly[1]);
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("cmp")) {
                            bw2.write("1110");
                            bw2.write(assembly[1]);
                            bw2.write(assembly[2]);
                        } else {
                            System.err.println("*** Code Generator ***");
                            System.err.println("Error: error in generating code");
                            System.exit(0);
                        }
                        if(assembly[k].equals("nop")) {
                            bw2.write("00000000");
                        } else if(assembly[k].equals("mvr")) {
                            bw2.write("0001");
                            bw2.write(assembly[k+1]);
                            bw2.write(assembly[k+2]);
                        } else if(assembly[k].equals("lda")) {
                            bw2.write("0010");
                            bw2.write(assembly[k+1]);
                            bw2.write(assembly[k+2]);
                        } else if(assembly[k].equals("sta")) {
                            bw2.write("0011");
                            bw2.write(assembly[k+1]);
                            bw2.write(assembly[k+2]);
                        } else if(assembly[k].equals("and")) {
                            bw2.write("0110");
                            bw2.write(assembly[k+1]);
                            bw2.write(assembly[k+2]);
                        } else if(assembly[k].equals("orr")) {
                            bw2.write("0111");
                            bw2.write(assembly[k+1]);
                            bw2.write(assembly[k+2]);
                        } else if(assembly[k].equals("not")) {
                            bw2.write("1000");
                            bw2.write(assembly[k+1]);
                        } else if(assembly[k].equals("add")) {
                            bw2.write("1011");
                            bw2.write(assembly[k+1]);
                            bw2.write(assembly[k+2]);
                        } else if(assembly[k].equals("sub")) {
                            bw2.write("1100");
                            bw2.write(assembly[k+1]);
                            bw2.write(assembly[k+2]);
                        } else if(assembly[k].equals("mul")) {
                            bw2.write("1101");
                            bw2.write(assembly[k+1]);
                            bw2.write(assembly[k+2]);
                        } else if(assembly[k].equals("cmp")) {
                            bw2.write("1110");
                            bw2.write(assembly[k+1]);
                            bw2.write(assembly[k+2]);
                        } else {
                            System.err.println("*** Code Generator ***");
                            System.err.println("Error: error in generating code");
                            System.exit(0);
                        }
                        bw2.write("\r\n");
                    } else {
                        bw.write(assembly[0]+" ");
                        for(i=1; i<(assembly.length-1); i++) {
                            bw.write(assembly[i]+",");
                            if(assembly[i].length()>4 && (assembly[i].substring(0,5).equals("low(#") || assembly[i].substring(0,6).equals("high(#"))) {
                                String t = assembly[i];
                                int n1,n2;
                                n1 = t.indexOf('#');
                                n2 = t.indexOf(')');
                                String s = String.format("%16s", Integer.toBinaryString(Integer.parseInt(t.substring(n1+1,n2)))).replace(' ', '0');
                                if(assembly[i].startsWith("low(")) {
                                    assembly[i] = s.substring(8);
                                } else if(assembly[i].startsWith("high(")) {
                                    assembly[i] = s.substring(0, 8);
                                }
                            } else if(assembly[i].length()>4 && (assembly[i].substring(0,4).equals("low(") || assembly[i].substring(0,5).equals("high("))) {
                                String t = assembly[i];
                                int n1,n2;
                                n1 = t.indexOf('(');
                                n2 = t.indexOf(')');
                                String s = String.format("%16s", Integer.toBinaryString(Integer.parseInt(t.substring(n1+1,n2)))).replace(' ', '0');
                                if(assembly[i].startsWith("low(")) {
                                    assembly[i] = s.substring(8);
                                } else if(assembly[i].startsWith("high(")) {
                                    assembly[i] = s.substring(0, 8);
                                }
                            } else if(assembly[i].charAt(0)=='t'){
                                assembly[i] = String.format("%2s", Integer.toBinaryString(Integer.parseInt(assembly[i].substring(1)))).replace(' ', '0');
                            } else {
                                assembly[i] = String.format("%8s", Integer.toBinaryString(Integer.parseInt(assembly[i]))).replace(' ', '0');
                            }
                        }
                        
                        bw.write(assembly[i]+"\r\n");
                        if(assembly[i].length()>4 && (assembly[i].substring(0,5).equals("low(#") || assembly[i].substring(0,6).equals("high(#"))) {
                            String t = assembly[i];
                            int n1,n2;
                            n1 = t.indexOf('#');
                            n2 = t.indexOf(')');
                            String s = String.format("%16s", Integer.toBinaryString(Integer.parseInt(t.substring(n1+1,n2)))).replace(' ', '0');
                            if(assembly[i].startsWith("low(")) {
                                assembly[i] = s.substring(8);
                            } else if(assembly[i].startsWith("high(")) {
                                assembly[i] = s.substring(0, 8);
                            }
                        } else if(assembly[i].length()>4 && (assembly[i].substring(0,4).equals("low(") || assembly[i].substring(0,5).equals("high("))) {
                            String t = assembly[i];
                            int n1,n2;
                            n1 = t.indexOf('(');
                            n2 = t.indexOf(')');
                            String s = String.format("%16s", Integer.toBinaryString(Integer.parseInt(t.substring(n1+1,n2)))).replace(' ', '0');
                            if(assembly[i].startsWith("low(")) {
                                assembly[i] = s.substring(8);
                            } else if(assembly[i].startsWith("high(")) {
                                assembly[i] = s.substring(0, 8);
                            }
                        } else if(assembly[i].charAt(0)=='t'){
                            assembly[i] = String.format("%2s", Integer.toBinaryString(Integer.parseInt(assembly[i].substring(1)))).replace(' ', '0');
                        } else {
                            assembly[i] = String.format("%8s", Integer.toBinaryString(Integer.parseInt(assembly[i]))).replace(' ', '0');
                        }
                        if(assembly[0].equals("mil")) {
                            bw2.write("1111");
                            bw2.write(assembly[1]);
                            bw2.write("00");      
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("mih")) {
                            bw2.write("1111");
                            bw2.write(assembly[1]);
                            bw2.write("01");
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("jpa")) {
                            bw2.write("1111");
                            bw2.write(assembly[1]);
                            bw2.write("11");
                            bw2.write(assembly[2]);
                        } else if(assembly[0].equals("jpr")) {
                            bw2.write("00000111");
                            bw2.write(assembly[1]);
                        } else if(assembly[0].equals("brz")) {
                            bw2.write("00001000");
                            bw2.write(assembly[1]);
                        } else if(assembly[0].equals("brc")) {
                            bw2.write("00001001");
                            bw2.write(assembly[1]);
                        } else {
                            System.err.println("*** Code Generator ***");
                            System.err.println("Error: error in generating code");
                            System.exit(0);
                        }
                        bw2.write("\r\n");
                    }
                }
                bw.write("hlt\t\t\t\t\tnop");
                bw2.write("0000000100000000");
            }
        }
    }
}