
package compiler;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


class Token {
    String token;
    int line;
    public Token(String t,int l) {
        token=t;
        line=l;
    }
}
//class symbolTableEntry {
//    String token;
//    int index;
//    int line;
//    symbolTableEntry(String t, int i, int l) {
//        token=t; index=i; line=l;
//    }
//}
//class keywordTableEntry {
//    int index;
//    String type;
//    keywordTableEntry(int i,String t) {
//        index=i; type=t;
//    }
//}
//class identifierTableEntry {
//    int index;
//    String value;
//    int registerAddress;
//    int memoryAddress;
//    identifierTableEntry(int i,String v,int r,int m) {
//        index=i; value=v; registerAddress=r; memoryAddress=m;
//    }
//}
//class numberTableEntry {
//    int index;
//    String name;
//    String value;
//    int registerAddress;
//    int memoryAddress;
//    numberTableEntry(int i,String n,String v,int r,int m) {
//        index=i; name=n; value=v; registerAddress=r; memoryAddress=m;
//    }
//}
//class characterTableEntry {
//    int index;
//    String name;
//    String value;
//    int registerAddress;
//    int memoryAddress;
//    characterTableEntry(int i,String n,String v,int r,int m) {
//        index=i; name=n; value=v; registerAddress=r; memoryAddress=m;
//    }
//}
//class operatorTableEntry {
//    int index;
//    String value;
//    operatorTableEntry(int i,String v) {
//        index=i; value=v;
//    }
//}
//class punctuationTableEntry {
//    int index;
//    String value;
//    punctuationTableEntry(int i,String v) {
//        index=i; value=v;
//    }
//}
//class regmemTableEntry {
//    int address;
//    String type;
//    regmemTableEntry(int a,String t) {
//        address=a; type=t;
//    }
//}
public class Compiler {
//    static List<symbolTableEntry> symbolTable;
//    static List<keywordTableEntry> keywordTable;
//    static List<identifierTableEntry> identifierTable;
//    static List<numberTableEntry> numberTable;
//    static List<characterTableEntry> characterTable;
//    static List<operatorTableEntry> operatorTable;
//    static List<punctuationTableEntry> punctuationTable;
//    static List<regmemTableEntry> regmemTable;
    static LexicalAnalyzer scanner;
    static SyntaxAnalyzer parser;
    static CodeGenerator generator;
    
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    static Token getRealToken() {
        if(!scanner.tokens.isEmpty()) {
            return scanner.tokens.poll();
        } else {
            return new Token("$",scanner.lineNumber);
        }
    }
    static Token getToken(Token t) {
        if(new ArrayList<>(Arrays.asList("if","else","while","int","char","bool","null","true","false")).contains(t.token)) {
            return t;
        } else if(new ArrayList<>(Arrays.asList("=","+=","-=","*=","/=","%=","&&","||","!","==","!=",">","<","<=",">=","+","-","*","/","++","--")).contains(t.token)) {
            return t;
        } else if(new ArrayList<>(Arrays.asList(",","(",")","{","}",":",";")).contains(t.token)) {
            return t;
        } else if(t.token.matches("[a-zA-Z][a-zA-Z0-9]*")) {
            return new Token("id",t.line);
        } else if(t.token.matches("[+-]*[0-9]+")) {
            return new Token("num",t.line);
        } else if(t.token.equals("$")) {
            return t;
        } else if(t.token.length()==1) {
            return new Token("char",t.line);
        } else {
            System.err.println("*** Syntax Analyzer ***");
            System.err.println("Error: Syntax error on line "+t.line);
            System.err.println("Error: Unidentified token found: "+t.token);
            System.err.println("Note: There should be an space between any token");
            System.exit(0);
        }
        return null;
    }
    public static void main(String[] args) throws IOException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        scanner=new LexicalAnalyzer("input.txt");
        generator = new CodeGenerator("output_code.txt","output_binary.txt");
        parser=new SyntaxAnalyzer();
        parser.startParsing();
        generator.generateCode();
        generator.assemblyCodes.clear();
        generator.semanticStack.clear();
//        symbolTable = new LinkedList<>();
//        keywordTable = new LinkedList<>();
//        identifierTable = new LinkedList<>();
//        numberTable = new LinkedList<>();
//        characterTable = new LinkedList<>();
//        operatorTable = new LinkedList<>();
//        punctuationTable = new LinkedList<>();
//        regmemTable = new LinkedList<>();
//        
//        for(Token t:scanner.tokens) {
//            if(new ArrayList<>(Arrays.asList("if","else","while","int","char","bool","null","true","false")).contains(t.token)) {
//                symbolTable.add(new symbolTableEntry("keyword",keywordTable.size(), t.line));
//                keywordTable.add(new keywordTableEntry(keywordTable.size(),t.token));
//            } else if(new ArrayList<>(Arrays.asList("=","+=","-+","*=","/=","%=","&&","||","!","==","!=",">","<","<=",">=","+","-","*","/","++","--")).contains(t.token)) {
//                symbolTable.add(new symbolTableEntry("operator",operatorTable.size(), t.line));
//                operatorTable.add(new operatorTableEntry(operatorTable.size(),t.token));
//            } else if(new ArrayList<>(Arrays.asList(",","(",")","{","}",":",";")).contains(t.token)) {
//                symbolTable.add(new symbolTableEntry("punctuation",punctuationTable.size(), t.line));
//                punctuationTable.add(new punctuationTableEntry(punctuationTable.size(),t.token));
//            } else if(t.token.matches("[a-zA-Z][a-zA-Z0-9]*")) {
//                symbolTable.add(new symbolTableEntry("identifier",identifierTable.size(), t.line));
//                identifierTable.add(new identifierTableEntry(identifierTable.size(),t.token,0,0));
//            } else if(t.token.matches("[+-]*[0-9]+")) {
//                symbolTable.add(new symbolTableEntry("number",numberTable.size(), t.line));
//                numberTable.add(new numberTableEntry(numberTable.size(),"s"+numberTable.size(),t.token,0,0));
//            } else if(t.token.length()==1) {
//                symbolTable.add(new symbolTableEntry("character",characterTable.size(), t.line));
//                characterTable.add(new characterTableEntry(characterTable.size(),"s"+numberTable.size(),t.token,0,0));
//            } else {
//                System.err.println("*** Lexical Analyzer ***");
//                System.err.println("Error: invalid token found on line "+t.line+" \""+t.token+"\"");
//                System.exit(0);
//            }
//        }
//        System.out.println("KEYWORD TABLE");
//        for(keywordTableEntry s:keywordTable) {
//            System.out.println(s.index+" - "+s.type);
//        }
//        System.out.println("IDENTIFIER TABLE");
//        for(identifierTableEntry s:identifierTable) {
//            System.out.println(s.index+" - "+s.value+" - "+s.registerAddress+" - "+s.memoryAddress);
//        }
//        System.out.println("SYMBOL TABLE");
//        for(symbolTableEntry s:symbolTable) {
//            System.out.println(s.token+" - "+s.index+" - "+s.line);
//        }
//        System.out.println("NUMBER TABLE");
//        for(numberTableEntry s:numberTable) {
//            System.out.println(s.index+" - "+s.name+" - "+s.value+" - "+s.registerAddress+" - "+s.memoryAddress);
//        }
//        System.out.println("OPERATOR TABLE");
//        for(operatorTableEntry s:operatorTable) {
//            System.out.println(s.index+" - "+s.value);
//        }
//        System.out.println("PUNCTUATION TABLE");
//        for(punctuationTableEntry s:punctuationTable) {
//            System.out.println(s.index+" - "+s.value);
//        }
//        System.out.println("CHARACTER TABLE");
//        for(characterTableEntry s:characterTable) {
//            System.out.println(s.index+" - "+s.name+" - "+s.value+" - "+s.registerAddress+" - "+s.memoryAddress);
//        }
//        
    }
    
}
